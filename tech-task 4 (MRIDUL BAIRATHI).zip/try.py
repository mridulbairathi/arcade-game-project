import os
import time
from kivy.core.text import Label

os.environ['KIVY_IMAGE'] = 'pil'
import sys
from kivy import Config

Config.set('graphics', 'multisamples', '0')
from kivy.core.window import Window
import kivy
from kivy.app import App
from kivy.properties import StringProperty
from kivy.lang import Builder
from kivy.uix.anchorlayout import AnchorLayout
import random

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.widget import Widget
from kivy.uix.screenmanager import *

class Arcade(BoxLayout):
    pass

class ArcadeGame(App):
    pass
ArcadeGame().run()