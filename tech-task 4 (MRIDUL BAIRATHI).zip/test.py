import os
os.environ['KIVY_IMAGE'] = 'pil'
import sys
from kivy import Config

Config.set('graphics', 'multisamples', '0')

from time import strftime

from kivy._clock import ClockEvent
from kivy.clock import Clock
from kivy.core.text import Label

from kivy.core.window import Window
import kivy
from kivy.app import App
from kivy.properties import StringProperty, NumericProperty,BooleanProperty
from kivy.lang import Builder
from kivy.uix.anchorlayout import AnchorLayout
import random

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.widget import Widget
from kivy.uix.screenmanager import ScreenManager,Screen




class tc(Screen):
    event=''
    event2=''
    file=open('tchighscore.txt','r')
    no=0
    numb=StringProperty(str(no))
    ver=BooleanProperty(True)
    ver1 = BooleanProperty(False)
    t='10'
    timer1=StringProperty(str(t))
    def click(self):
        self.no=self.no+1
        self.numb=(str(self.no))


    def start(self):
        self.ver = (False)
        self.ver1=(True)
        self.event=Clock.schedule_interval(self.timer, 1)
        self.event2=Clock.schedule_once(self.stopgame,10)

    def timer(self,*args):

        t=int(self.timer1)-1
        self.timer1=str(t)
    def stopgame(self,*args):


            self.ver = (True)
            self.timer1 = f'TIME OVER!! YOUR SCORE IS {self.no} '

            filf=self.file.read()

            if filf=='':
                self.file.close()
                file1 = open('tchighscore.txt', 'w')
                file1.write(str(self.no))
                self.numb = f'highscore is {self.no}'


            elif int(filf) <self.no:
                self.file.close()
                file1=open('tchighscore.txt','w')
                file1.write(str(self.no))
                self.numb=f'highscore is {self.no}'
            else:
                self.numb = f'highscore is {filf}'


            self.event.cancel()

    def endgame(self):
        if self.timer1!='10':
            self.event.cancel()
            self.event2.cancel()
            self.file = open('tchighscore.txt', 'r')
            self.no = 0
            self.numb = (str(self.no))
            self.ver = (True)
            self.ver1 = (False)
            self.t = '10'
            self.timer1 = (str(self.t))
        Myapp.sm.current='end'




class Mybutton(Screen):





    mytext = StringProperty( '''rules:
        1. find the movie by gussing the letters
        2. all vowels will be given only consonents to be guessed
        3. for every wrong guess a letter form word BOLLYWOOD WOULD DELETE 
        4. if the letter in BOLLYWOOD to be deleted is same as the wrong letter guessed no letter would be deleted
        5. PRESS ANY BUTTON TO START''')
    X = 'bollywood'
    GAME = StringProperty(X)
    u = []
    letters = StringProperty(str(u))
    f = open('bollywood.txt', 'r')  # opening file where movies are stored
    g = f.readlines()  # reading the file line by line
    k = random.randint(0, len(g))  # creating a variable which can acess all the elements of file
    t = g[k].lower().lstrip().rstrip().replace(' ', '/')  # removing white spaces and add / to dist. b/w 2 words
    q = g[k].lower().lstrip().rstrip()  # creating a copy of movie
    m = ['A', 'e', 'i', 'o', 'u', 'a', 'E', 'O', 'I', 'U', ' ', ':', ';', ',', '.', '?', '!', '/', '-', '&', '_',
         '>', '<', '*', '+', '|', '@', '#']# variable that is to be printed in every movie name

    y = 0
    gamestart=0




    def onclick(self, button):
        if self.gamestart == 1:
            self.gamestart = 0
            self.y = 0
            self.X = 'bollywood'
            self.mytext = ('''rules:
                                        1. find the movie by gussing the letters
                                        2. all vowels will be given only consonents to be guessed
                                        3. for every wrong guess a letter form word BOLLYWOOD WOULD DELETE 
                                        4. if the letter in BOLLYWOOD to be deleted is same as the wrong letter guessed no letter would be deleted
                                        5. PRESS ANY BUTTON TO START''')
            self.u = []
            self.letters = (str(self.u))
            self.GAME = (self.X)
            self.f = open('bollywood.txt', 'r')  # opening file where movies are stored
            self.g = self.f.readlines()  # reading the file line by line
            self.k = random.randint(0, len(self.g))  # creating a variable which can acess all the elements of file
            self.t = self.g[self.k].lower().lstrip().rstrip().replace(' ', '/')

            self.q = self.g[self.k].lower().lstrip().rstrip()  # creating a copy of movie
            self.m = ['A', 'e', 'i', 'o', 'u', 'a', 'E', 'O', 'I', 'U', ' ', ':', ';', ',', '.', '?', '!', '/', '-',
                      '&', '_',
                      '>', '<', '*', '+', '|', '@', '#']  # variable that is to be printed in every movie name
            return
        x=0
        self.word = str(button.text).lower()
        #print(self.word)

        def wordprint(t):# creating a function to remove all consonents and add blanks
            global z
            z = ''
            h = t


            for j in t:

                if j in self.m:
                    z = z + j
                else:
                    z = z + '_ '
            self.mytext=z

        if self.y==0:
            self.y = self.y + 1
            wordprint(self.t)
            return

        if z == self.t or self.X == '':
            self.gamestart=1

            Myapp.sm.current = 'end'

        if self.word not in self.t:
            if self.word not in self.m:

                if self.word not in self.u:
                    self.u.append(self.word)
                    self.letters = (f'{self.word} is not in name '+str(self.u))

                    #wordprint(self.t)
                    if self.word == self.X[x]:
                        pass
                    else:
                        x = x + 1
                        #print(x)
                        self.X = self.X[x:len(self.X)]
                        self.GAME = self.X
                        if self.X == '':

                            self.mytext=('u lose')

                            self.mytext =('movie was '+str(self.q).upper())



                else:
                    self.letters=(f'{self.word} is an already inputted wrong letter '+str(self.u))
            else:
                self.letters='entering vowels is not allowed '+str(self.u)
        else:

                self.m.append(self.word)
                self.GAME=self.X
                self.letters = (f'{self.word} is in the name ' + str(self.u))
                wordprint(self.t)

                if z == self.t:
                    self.GAME='YES!!! MOVIE WAS '+str(self.q).upper()
                    self.letters="Press Any Key To Exit"


                    self.mytext='CONGRATULATIONS!!!!YOU WON!!!! '+'your points are '+str(len(self.X))
                    self.f.close()

    def gameend(self):
        self.y = 0
        self.X = 'bollywood'
        self.mytext = ('''rules:
                1. find the movie by gussing the letters
                2. all vowels will be given only consonents to be guessed
                3. for every wrong guess a letter form word BOLLYWOOD WOULD DELETE 
                4. if the letter in BOLLYWOOD to be deleted is same as the wrong letter guessed no letter would be deleted
                5. PRESS ANY BUTTON TO START''')
        self.u = []
        self.letters = (str(self.u))
        self.GAME = (self.X)
        self.f = open('bollywood.txt', 'r')  # opening file where movies are stored
        self.g = self.f.readlines()  # reading the file line by line
        self.k = random.randint(0, len(self.g))  # creating a variable which can acess all the elements of file
        self.t = self.g[self.k].lower().lstrip().rstrip().replace(' ', '/')

        self.q = self.g[self.k].lower().lstrip().rstrip()  # creating a copy of movie
        self.m = ['A', 'e', 'i', 'o', 'u', 'a', 'E', 'O', 'I', 'U', ' ', ':', ';', ',', '.', '?', '!', '/', '-', '&', '_',
             '>', '<', '*', '+', '|', '@', '#']  # variable that is to be printed in every movie name


        Myapp.sm.current = 'end'
class sps(Screen):


    itc=0  # for running the game close command
    cpo=0
    po=0
    points=StringProperty(f'your points are {po}          '+f'computer\'s points are {cpo}')
    roundno=1
    comp=StringProperty('')
    x=0
    info=StringProperty('''RULES:
ROCK WINS OVER SCISSOR
SCISSOR WINS OVER PAPER 
PAPER WINS OVER ROCK
MAKE THE HIGHST SCORE AND WIN THE GAME 
TOTAL OF 10 ROUNDS WOULD BE THERE 
TOUCH ANY BUTTON TO START''')
    gamestart = 0
    def gameend(self):
        self.itc = 0  # for running the game close command
        self.cpo = 0
        self.po = 0
        self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}')
        self.roundno = 1
        self.comp = ('')
        self.x = 0
        self.info = ('''RULES:
        ROCK WINS OVER SCISSOR
        SCISSOR WINS OVER PAPER 
        PAPER WINS OVER ROCK
        MAKE THE HIGHST SCORE AND WIN THE GAME 
        TOTAL OF 10 ROUNDS WOULD BE THERE 
        TOUCH ANY BUTTON TO START''')
        Myapp.sm.current='end'


    def game(self,button):



        file = open('highscore.txt', 'r+')
        a = ['rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper',
             'scissor',
             'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper',
             'scissor',
             'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor',
             'rock',
             'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor''rock', 'paper', 'scissor',
             'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor',
             'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper',
             'scissor',
             'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor',
             'rock',
             'paper', 'scissor', 'rock', 'paper', 'scissor', 'rock', 'paper', 'scissor']
        k = random.randrange(0, len(a))
        op = a[k]




        if self.x == 0:
            self.x = 1

            self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}        ' + f'ROUND{self.roundno}')
            self.info = ("game started")
            return


        if self.roundno>=12:



            Myapp.sm.current='end'
            self.gamestart = 0
            self.itc = 0  # for running the game close command
            self.cpo = 0
            self.po = 0
            self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}')
            self.roundno = 1
            self.comp = ('')
            self.x = 0
            self.info = ('''RULES:
                                ROCK WINS OVER SCISSOR
                                SCISSOR WINS OVER PAPER 
                                PAPER WINS OVER ROCK
                                MAKE THE HIGHST SCORE AND WIN THE GAME 
                                TOTAL OF 10 ROUNDS WOULD BE THERE 
                                TOUCH ANY BUTTON TO START''')
            return

        choice = str(button.text)
        if self.roundno<=10:

            if op==choice:
                self.info=("tie match   "+f'round{self.roundno} continuing')
                self.comp=(f"your choice was {choice}        "+f"computer chose {op} ")

                self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}        ' + f'ROUND{self.roundno}')



            else:


                if op=='rock' and choice=='scissor':

                    self.info=("you lose   ")
                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.cpo=self.cpo+1



                elif op=='rock' and choice=='paper':

                    self.info=('you won   ')

                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.po = self.po + 1




                elif op=='paper' and choice=='scissor':

                    self.info=('you won   ')

                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.po = self.po + 1




                elif op=='paper' and choice=='rock':

                    self.info = ("you lose   ")
                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.cpo = self.cpo + 1




                elif op == 'scissor' and choice == 'paper':

                    self.info = ("you lose   ")
                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.cpo = self.cpo + 1




                elif op == 'scissor' and choice == 'rock':

                    self.info = ('you won    ')

                    self.comp = (f"your choice was {choice}        " + f"computer chose {op} ")
                    self.po = self.po + 1

                self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}        ' + f'ROUND{self.roundno}')
                self.roundno = self.roundno + 1

        else:
            self.roundno = self.roundno + 1
            if self.cpo>self.po:
                self.info=("YOU LOSE")
                self.comp=('')
                self.points=(f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}')


            elif self.cpo<self.po:
                self.info=("YOU WON")
                self.comp = (f"highscore is {self.po}")
                self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}')


            else:

                self.info=("TIE MATCH")

                self.points = (f'your points are {self.po}          ' + f'computer\'s points are {self.cpo}')
            f = file.read()
            if f == '':
                file.write(str(self.po))
                self.comp = (f"highscore is {self.po}")
            elif int(f) < self.po:


                    self.comp = (f"highscore is {self.po}")
                    file.close()
                    file1 = open('highscore.txt', 'w')

                    file1.write(str(self.po))
            else:
                self.comp = (f"highscore is {f}")




class end(Screen):
    def end(self):

        Myapp.sm.current='main'


class check(Screen):
    def begin(self):
        Myapp.sm.current='bol'
    def sps(self):
        Myapp.sm.current = 'sps'

    def tc(self):
        Myapp.sm.current='tc'

class Myapp(App):
    sm = ScreenManager()
    def build(self):

        one = check(name='main')
        bol = Mybutton(name='bol')
        end1 = end(name='end')
        sps1=sps(name='sps')
        tapc=tc(name='tc')

        self.sm.add_widget(one)
        self.sm.add_widget(bol)
        self.sm.add_widget(sps1)
        self.sm.add_widget(end1)
        self.sm.add_widget(tapc)

        return self.sm

if __name__=='__main__':

    Myapp().run()































