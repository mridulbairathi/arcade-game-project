import os
os.environ['KIVY_IMAGE'] = 'pil'
import sys
from kivy import Config

Config.set('graphics', 'multisamples', '0')
from kivy.core.window import Window
import kivy
from kivy.app import App
from kivy.properties import StringProperty
from kivy.lang import Builder
from kivy.uix.anchorlayout import AnchorLayout
import random

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.widget import Widget



class Mybutton(BoxLayout):

    mytext=StringProperty('press any button to start')
    X='bollywood'
    GAME = StringProperty(X)
    u = []
    letters=StringProperty(str(u))
    f = open('bollywood.txt', 'r')  # opening file where movies are stored
    g = f.readlines()  # reading the file line by line

    k = random.randint(0, len(g))  # creating a variable which can acess all the elements of file
    t = g[k].lower().lstrip().rstrip().replace(' ', '/')  # removing white spaces and add / to dist. b/w 2 words
    q = g[k].lower().lstrip().rstrip()  # creating a copy of movie
    # variable that is to be printed in every movie name
    m = ['A', 'e', 'i', 'o', 'u', 'a', 'E', 'O', 'I', 'U', ' ', ':', ';', ',', '.', '?', '!', '/','-']



    y=0


    def onclick(self, button):
        x=0


        self.word = str(button.text).lower()
        print(self.word)

        def wordprint(t):# creating a function to remove all consonents and add blanks
            global z
            z = ''
            h = t

            for j in t:

                if j in self.m:
                    z = z + j
                else:
                    z = z + '_ '
            self.mytext=z
        if self.y==0:
            self.y = self.y + 1
            wordprint(self.t)

            return

        if self.word not in self.t:
            if self.word not in self.m:
                if self.word not in self.u:
                    self.u.append(self.word)
                    self.letters = ('not in movie'+str(self.u))

                    #wordprint(self.t)
                    if self.word == self.X[x]:
                        print('hello')
                    else:
                        x = x + 1
                        print(x)
                        self.X = self.X[x:len(self.X)]
                        self.GAME = self.X
                        if self.X == '':
                            self.mytext=('u lose')

                            self.mytext =('movie was '+str(self.q).upper())


                else:
                    self.letters=('already inputted wrong letter '+str(self.u))
            else:
                self.letters='entering vowels is not allowed'+str(self.u)
        else:

                self.m.append(self.word)
                self.GAME=self.X

                wordprint(self.t)
                if z == self.t:
                    self.GAME='YES!!! MOVIE WAS '+str(self.q).upper()
                    self.letters="CONGRATULATIONS!!!!"
                    self.mytext='YOU WON!!!! '+'your points are'+str(len(self.X))

                    self.f.close()



class Myapp(App):

    def build(self):
        return Mybutton()


Myapp().run()
